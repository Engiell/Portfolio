import sys
from database import initialize_db
from service import (
    add_user,
    authenticate_user,
    get_user_by_email,
    get_user_itineraries,
    add_destination,
    create_itinerary,
    add_itinerary_detail
)

def prompt_existing_user():
    print("\n=== Existing User Login ===")
    try:
        user_id = int(input("Enter your User ID: ").strip())
    except ValueError:
        print("Please enter a numeric User ID.")
        return prompt_existing_user()

    password = input("Enter your password: ").strip()
    if authenticate_user(user_id, password):
        print("Login successful.")
        return user_id
    else:
        print("Invalid ID or password. Try again.")
        return prompt_existing_user()

def prompt_new_user():
    print("\n=== New User Registration ===")
    while True:
        name = input("Name: ").strip()
        email = input("Email: ").strip()
        password = input("Password: ").strip()

        existing_id = get_user_by_email(email)
        if existing_id:
            print(f"Email '{email}' is already registered under User ID {existing_id}.")
            choice = input("Type 'L' to login, or any other key to try a different email: ").strip().lower()
            if choice == 'l':
                return prompt_existing_user()
            else:
                continue

        user_id = add_user(name, email, password)
        print(f"Registration complete. Your new User ID is {user_id}.")
        return user_id

def show_itineraries(user_id: int):
    print("\n=== View Itineraries ===")
    start_date = input("Show itineraries starting on or after (YYYY-MM-DD): ").strip()
    trips = get_user_itineraries(user_id, start_date)

    if not trips:
        print("No itineraries found for that period.")
        return

    print(f"\nFound {len(trips)} itinerary entries:\n")
    for t in trips:
        print(
            f"Itin#{t['itinerary_id']} | "
            f"{t['city']}, {t['country']} | "
            f"{t['accommodation']} | notes: {t['notes']}"
        )

def prompt_add_destination() -> int:
    print("\n=== Add a Destination ===")
    city = input("City: ").strip()
    country = input("Country: ").strip()
    description = input("Short description (optional): ").strip() or None
    dest_id = add_destination(city, country, description)
    print(f"Destination '{city}, {country}' added with ID {dest_id}")
    return dest_id

def prompt_create_itinerary(user_id: int) -> int:
    print("\n=== Create New Itinerary ===")
    start_date = input("Start date (YYYY-MM-DD): ").strip()
    end_date = input("End date (YYYY-MM-DD): ").strip()
    itin_id = create_itinerary(user_id, start_date, end_date)
    print(f"Itinerary created with ID {itin_id}")
    return itin_id

def prompt_add_itinerary_detail(itin_id: int, dest_id: int):
    print("\n=== Add Itinerary Details ===")
    accommodation = input("Accommodation (optional): ").strip() or None
    notes = input("Notes (optional): ").strip() or None
    detail_id = add_itinerary_detail(itin_id, dest_id, accommodation, notes)
    print(f"Itinerary detail added with ID {detail_id}")

def main():
    initialize_db()

    print("Welcome to the SNHU Travel Console\n")
    choice = input("Are you an existing user? (Y/N): ").strip().lower()

    if choice == 'y':
        user_id = prompt_existing_user()
    else:
        user_id = prompt_new_user()

    show_itineraries(user_id)

    choice = input("\nWould you like to add a new itinerary? (Y/N): ").strip().lower()
    if choice == 'y':
        dest_id = prompt_add_destination()
        itin_id = prompt_create_itinerary(user_id)
        prompt_add_itinerary_detail(itin_id, dest_id)
        print("\nItinerary successfully created!")

    print("\nPress [Enter] to exit.")
    input()
    sys.exit(0)

if __name__ == "__main__":
    main()
