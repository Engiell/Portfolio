// Enhanced Thermostat System for Arduino
// Author: Anthony W Bradley
// Python-based thermostat logic converted to C++ for microcontroller deployment.

#include <Arduino.h>

// -------------------- CONFIG --------------------
const int redLEDPin = 8;
const int blueLEDPin = 9;
const int tempSensorPin = A0; // Simulated analog input

const int setPointDefault = 72;
const int updateInterval = 5000; // milliseconds

// -------------------- STATE MANAGEMENT -----------
enum ThermostatState {
    OFF,
    HEAT,
    COOL
};

ThermostatState currentState = OFF;
int setPoint = setPointDefault;
float lastTempF = 72.0;

// -------------------- UTILITY --------------------
float readTemperatureF() {
    int analogValue = analogRead(tempSensorPin);
    float voltage = analogValue * (5.0 / 1023.0);
    float celsius = (voltage - 0.5) * 100;
    float fahrenheit = (celsius * 9.0 / 5.0) + 32;
    lastTempF = fahrenheit;
    return fahrenheit;
}

void updateLEDs(float tempF) {
    digitalWrite(redLEDPin, LOW);
    digitalWrite(blueLEDPin, LOW);

    if (currentState == HEAT) {
        if (tempF < setPoint) {
            digitalWrite(redLEDPin, HIGH);
        }
    }
    else if (currentState == COOL) {
        if (tempF > setPoint) {
            digitalWrite(blueLEDPin, HIGH);
        }
    }
}

void cycleState() {
    switch (currentState) {
    case OFF:
        currentState = HEAT;
        break;
    case HEAT:
        currentState = COOL;
        break;
    case COOL:
        currentState = OFF;
        break;
    }
}

// -------------------- SETUP --------------------
void setup() {
    pinMode(redLEDPin, OUTPUT);
    pinMode(blueLEDPin, OUTPUT);
    pinMode(tempSensorPin, INPUT);

    Serial.begin(115200);
    delay(1000);
    Serial.println("Thermostat System Initialized.");
}

// -------------------- LOOP --------------------
void loop() {
    float currentTemp = readTemperatureF();
    updateLEDs(currentTemp);

    // Output system status
    Serial.print("State: ");
    switch (currentState) {
    case OFF: Serial.print("OFF"); break;
    case HEAT: Serial.print("HEAT"); break;
    case COOL: Serial.print("COOL"); break;
    }
    Serial.print(", Temp: ");
    Serial.print(currentTemp);
    Serial.print("F, SetPoint: ");
    Serial.println(setPoint);

    delay(updateInterval);

    
    cycleState();          // Simulate button to change state
    setPoint += 1;         // Simulate button to raise temperature
    if (setPoint > 78) setPoint = setPointDefault; // Reset logic
}